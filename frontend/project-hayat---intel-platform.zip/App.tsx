
import React, { useState, useEffect } from 'react';
import { 
  ShieldAlert, 
  Wifi, 
  Battery, 
  Signal, 
  Map as MapIcon, 
  Crosshair, 
  Zap, 
  Activity, 
  Navigation2,
  Cpu,
  RefreshCw,
  Loader2
} from 'lucide-react';
import { MOCK_DETECTIONS, getIconForType } from './constants';
import { Priority, Detection, RescuePlan } from './types';
import { generateRescuePlan } from './services/geminiService';

const App: React.FC = () => {
  const [detections] = useState<Detection[]>(MOCK_DETECTIONS);
  const [isGenerating, setIsGenerating] = useState(false);
  const [rescuePlan, setRescuePlan] = useState<RescuePlan | null>(null);
  const [activeTab, setActiveTab] = useState<'detections' | 'telemetry'>('detections');

  const handleGenerateRoute = async () => {
    setIsGenerating(true);
    const plan = await generateRescuePlan(detections);
    setRescuePlan(plan);
    setIsGenerating(false);
  };

  return (
    <div className="flex flex-col h-screen bg-slate-900 text-slate-50 selection:bg-cyan-500/30 font-mono">
      {/* Top Navigation */}
      <header className="h-16 border-b border-slate-800 bg-slate-900/80 backdrop-blur-md flex items-center justify-between px-6 z-50">
        <div className="flex items-center gap-4">
          <div className="bg-red-600 p-1.5 rounded-sm">
            <ShieldAlert className="text-white" size={20} />
          </div>
          <h1 className="text-lg font-bold tracking-tighter">
            PROJECT HAYAT <span className="text-slate-500 font-light">// INTEL PLATFORM</span>
          </h1>
        </div>

        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2 bg-slate-800/50 px-3 py-1 rounded-full border border-slate-700">
            <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-xs font-semibold text-emerald-400">LIVE OPS: TURKEY-SYRIA BORDER</span>
          </div>
          
          <div className="flex items-center gap-4 text-slate-400">
            <div className="flex items-center gap-1.5">
              <Wifi size={16} className="text-emerald-500" />
              <span className="text-[10px] uppercase tracking-widest">Network Stable</span>
            </div>
            <div className="h-4 w-px bg-slate-700" />
            <span className="text-xs tabular-nums">{new Date().toLocaleTimeString()}</span>
          </div>
        </div>
      </header>

      <main className="flex-1 flex overflow-hidden">
        {/* Left Sidebar - Intelligence Log */}
        <aside className="w-80 border-r border-slate-800 flex flex-col bg-slate-900/50">
          <div className="p-4 border-b border-slate-800 flex items-center justify-between">
            <h2 className="text-xs font-bold tracking-[0.2em] text-slate-500 uppercase flex items-center gap-2">
              <Activity size={14} className="text-cyan-400" />
              Real-Time Detection Feed
            </h2>
            <span className="text-[10px] bg-slate-800 text-slate-400 px-1.5 py-0.5 rounded uppercase">Active</span>
          </div>
          
          <div className="flex-1 overflow-y-auto p-3 space-y-3">
            {detections.map((det) => (
              <div 
                key={det.id} 
                className="group relative bg-slate-800/30 border border-slate-800 p-3 rounded-sm hover:border-slate-600 transition-all cursor-pointer overflow-hidden"
              >
                <div className={`absolute top-0 left-0 w-1 h-full ${
                  det.priority === Priority.CRITICAL ? 'bg-red-500' : 
                  det.priority === Priority.HIGH ? 'bg-orange-500' : 'bg-blue-500'
                }`} />
                <div className="flex justify-between items-start mb-2">
                  <div className="flex items-center gap-2">
                    <div className={`${
                      det.type === 'Voice' ? 'text-cyan-400' : 
                      det.type === 'Hazard' ? 'text-red-400' : 
                      det.type === 'Thermal' ? 'text-orange-400' : 'text-slate-400'
                    }`}>
                      {getIconForType(det.type)}
                    </div>
                    <span className="text-xs font-bold uppercase tracking-tight">{det.description}</span>
                  </div>
                  <span className="text-[10px] text-slate-500 tabular-nums">{det.time}</span>
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="flex gap-1.5">
                    <span className={`text-[9px] px-1.5 py-0.5 rounded-sm font-bold border uppercase ${
                      det.priority === Priority.CRITICAL ? 'border-red-500/50 text-red-500' : 
                      det.priority === Priority.HIGH ? 'border-orange-500/50 text-orange-500' : 'border-slate-700 text-slate-500'
                    }`}>
                      {det.priority}
                    </span>
                    <span className="text-[9px] px-1.5 py-0.5 rounded-sm font-bold border border-cyan-500/50 text-cyan-500 uppercase">
                      {(det.confidence * 100).toFixed(0)}% CONF
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          <div className="p-4 border-t border-slate-800 bg-slate-900">
             <div className="flex items-center justify-between text-[10px] text-slate-500 mb-2">
               <span>SYSTEM UPTIME: 14h 22m</span>
               <span>v4.2.1-stable</span>
             </div>
             <div className="w-full h-1 bg-slate-800 rounded-full overflow-hidden">
               <div className="w-3/4 h-full bg-cyan-500 animate-pulse" />
             </div>
          </div>
        </aside>

        {/* Center Main Area - The Map Placeholder */}
        <section className="flex-1 relative bg-[#020617] overflow-hidden group">
          {/* Mock Map Background */}
          <div className="absolute inset-0 opacity-20">
             <div className="w-full h-full bg-[url('https://picsum.photos/1920/1080?grayscale')] bg-cover bg-center mix-blend-overlay" />
          </div>

          {/* Grid Overlay */}
          <div className="absolute inset-0 bg-[linear-gradient(to_right,#1e293b_1px,transparent_1px),linear-gradient(to_bottom,#1e293b_1px,transparent_1px)] bg-[size:40px_40px] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_50%,#000_70%,transparent_100%)]" />

          {/* HUD Static Elements */}
          <div className="absolute inset-0 pointer-events-none p-6 flex flex-col justify-between">
            <div className="flex justify-between items-start">
               <div className="space-y-1">
                 <div className="flex items-center gap-2 text-cyan-400">
                    <Crosshair size={18} />
                    <span className="text-sm font-bold tracking-widest">UAV-ALPHA-7 // TARGETING</span>
                 </div>
                 <div className="text-[10px] text-slate-500 uppercase">
                    36.2023° N, 36.1601° E | ALT: 142m
                 </div>
               </div>
               <div className="flex gap-4">
                  <div className="text-right">
                    <div className="text-[10px] text-slate-500">PITCH</div>
                    <div className="text-sm">+0.14°</div>
                  </div>
                  <div className="text-right">
                    <div className="text-[10px] text-slate-500">ROLL</div>
                    <div className="text-sm">-0.02°</div>
                  </div>
                  <div className="text-right">
                    <div className="text-[10px] text-slate-500">YAW</div>
                    <div className="text-sm">284.1°</div>
                  </div>
               </div>
            </div>

            <div className="flex justify-between items-end">
               <div className="w-48 h-24 border border-slate-700/50 bg-slate-900/40 backdrop-blur-sm p-2">
                 <div className="text-[10px] text-slate-500 mb-1 uppercase tracking-wider">Compass</div>
                 <div className="flex items-center justify-center h-12">
                   <div className="relative w-full h-px bg-slate-700">
                     <div className="absolute top-1/2 left-[284px/3.6%] -translate-y-1/2 w-4 h-4 border border-cyan-500 rotate-45" />
                     <div className="absolute left-0 text-[8px] -top-3 text-slate-500 uppercase">W</div>
                     <div className="absolute left-1/2 -translate-x-1/2 text-[8px] -top-3 text-slate-500 uppercase font-bold text-cyan-500">N</div>
                     <div className="absolute right-0 text-[8px] -top-3 text-slate-500 uppercase">E</div>
                   </div>
                 </div>
               </div>
               <div className="space-y-1 text-right">
                  <div className="text-xs font-bold text-slate-400">THERMAL CAM ACTIVE</div>
                  <div className="text-[10px] text-slate-600">FR: 60FPS | BIT: 4.2MBPS</div>
               </div>
            </div>
          </div>

          {/* Scanning Animation */}
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
             <div className="relative w-64 h-64 border border-cyan-500/20 rounded-full flex items-center justify-center animate-pulse">
                <div className="absolute inset-0 border border-cyan-500/10 rounded-full animate-ping" />
                <div className="w-1 h-1 bg-cyan-400 rounded-full shadow-[0_0_15px_#22d3ee]" />
                <div className="absolute w-48 h-px bg-gradient-to-r from-transparent via-cyan-500/40 to-transparent rotate-45" />
                <div className="absolute w-48 h-px bg-gradient-to-r from-transparent via-cyan-500/40 to-transparent -rotate-45" />
             </div>
          </div>

          {/* Markers on Map */}
          {detections.map((det, i) => (
             <div 
               key={det.id}
               className="absolute cursor-pointer transition-transform hover:scale-110"
               style={{
                 left: `${40 + (i * 12)}%`,
                 top: `${30 + (i * 10)}%`
               }}
             >
                <div className="group relative">
                  <div className={`p-1 border rounded-sm ${
                    det.priority === Priority.CRITICAL ? 'bg-red-500/20 border-red-500' : 
                    det.priority === Priority.HIGH ? 'bg-orange-500/20 border-orange-500' : 'bg-cyan-500/20 border-cyan-500'
                  }`}>
                    {getIconForType(det.type)}
                  </div>
                  <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 bg-slate-900 border border-slate-700 p-2 text-[10px] w-32 hidden group-hover:block z-50">
                    <div className="font-bold text-slate-300">{det.type}</div>
                    <div className="text-slate-500">{det.coordinates.lat}, {det.coordinates.lng}</div>
                  </div>
                </div>
             </div>
          ))}

          {/* Scanline Overlay */}
          <div className="hud-scanline absolute inset-0 z-10" />
        </section>

        {/* Right Sidebar - Drone Telemetry & Actionable Intel */}
        <aside className="w-80 border-l border-slate-800 flex flex-col bg-slate-900/50">
          <div className="p-4 border-b border-slate-800 flex items-center justify-between">
            <h2 className="text-xs font-bold tracking-[0.2em] text-slate-500 uppercase flex items-center gap-2">
              <Navigation2 size={14} className="text-emerald-400" />
              UAV Status
            </h2>
          </div>

          <div className="p-4 space-y-6 flex-1 overflow-y-auto">
            {/* Circular Progress Bars */}
            <div className="flex gap-4">
               <div className="flex-1 bg-slate-800/20 border border-slate-800 p-3 rounded-sm text-center">
                  <div className="text-[10px] text-slate-500 uppercase mb-2">Battery</div>
                  <div className="relative inline-flex items-center justify-center">
                     <svg className="w-16 h-16">
                        <circle className="text-slate-800" strokeWidth="4" stroke="currentColor" fill="transparent" r="28" cx="32" cy="32"/>
                        <circle className="text-emerald-500" strokeWidth="4" strokeDasharray="176" strokeDashoffset={176 * 0.26} strokeLinecap="round" stroke="currentColor" fill="transparent" r="28" cx="32" cy="32"/>
                     </svg>
                     <span className="absolute text-xs font-bold text-emerald-400">74%</span>
                  </div>
               </div>
               <div className="flex-1 bg-slate-800/20 border border-slate-800 p-3 rounded-sm text-center">
                  <div className="text-[10px] text-slate-500 uppercase mb-2">Signal</div>
                  <div className="relative inline-flex items-center justify-center">
                     <svg className="w-16 h-16">
                        <circle className="text-slate-800" strokeWidth="4" stroke="currentColor" fill="transparent" r="28" cx="32" cy="32"/>
                        <circle className="text-cyan-500" strokeWidth="4" strokeDasharray="176" strokeDashoffset={176 * 0.08} strokeLinecap="round" stroke="currentColor" fill="transparent" r="28" cx="32" cy="32"/>
                     </svg>
                     <span className="absolute text-xs font-bold text-cyan-400">92%</span>
                  </div>
               </div>
            </div>

            {/* Actionable Intel Section */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
                  <Zap size={14} className="text-yellow-400" />
                  Actionable Intel
                </h3>
                {rescuePlan && (
                  <button onClick={() => setRescuePlan(null)} className="text-[10px] text-slate-500 hover:text-slate-300">Clear</button>
                )}
              </div>

              {rescuePlan ? (
                <div className="bg-slate-800/40 border border-emerald-500/30 p-4 rounded-sm animate-in fade-in slide-in-from-right-4 duration-500">
                  <div className="text-xs font-bold text-emerald-400 mb-2 uppercase flex items-center gap-2">
                    <ShieldAlert size={14} /> AI Intel Report
                  </div>
                  <p className="text-[11px] text-slate-300 leading-relaxed mb-4 italic">
                    "{rescuePlan.summary}"
                  </p>
                  
                  <div className="space-y-3">
                    <div>
                      <div className="text-[10px] text-slate-500 uppercase mb-1 font-bold">Priority Zones</div>
                      <div className="flex flex-wrap gap-1">
                        {rescuePlan.priorityZones.map((zone, idx) => (
                          <span key={idx} className="bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded-sm text-[9px] text-emerald-400">
                            {zone}
                          </span>
                        ))}
                      </div>
                    </div>

                    <div>
                      <div className="text-[10px] text-slate-500 uppercase mb-1 font-bold">Strategic Routing</div>
                      <p className="text-[10px] text-slate-400">{rescuePlan.safePath}</p>
                    </div>

                    <div className="pt-2 border-t border-slate-700">
                      <div className="text-[10px] text-red-400 uppercase mb-1 font-bold">Tactical Warnings</div>
                      <ul className="text-[9px] text-red-500/70 list-disc list-inside space-y-0.5">
                        {rescuePlan.warnings.map((warning, idx) => (
                          <li key={idx}>{warning}</li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="bg-slate-800/10 border border-slate-800 border-dashed p-8 rounded-sm text-center flex flex-col items-center justify-center opacity-60">
                  <Cpu size={24} className="text-slate-700 mb-2" />
                  <p className="text-[10px] text-slate-600 uppercase tracking-wider">
                    Awaiting Rescue Intelligence Analysis
                  </p>
                </div>
              )}
            </div>

            {/* Primary CTA */}
            <div className="pt-4">
              <button 
                onClick={handleGenerateRoute}
                disabled={isGenerating}
                className={`w-full py-4 rounded-sm flex items-center justify-center gap-3 transition-all ${
                  isGenerating 
                    ? 'bg-slate-800 text-slate-500 cursor-not-allowed' 
                    : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-[0_0_20px_rgba(16,185,129,0.3)] hover:shadow-[0_0_25px_rgba(16,185,129,0.4)]'
                }`}
              >
                {isGenerating ? (
                  <>
                    <Loader2 size={18} className="animate-spin" />
                    <span className="text-xs font-bold uppercase tracking-[0.2em]">Processing Intel...</span>
                  </>
                ) : (
                  <>
                    <RefreshCw size={18} />
                    <span className="text-xs font-bold uppercase tracking-[0.2em]">Generate Rescue Route</span>
                  </>
                )}
              </button>
              <p className="text-[9px] text-center text-slate-600 mt-3 uppercase tracking-widest leading-relaxed">
                Powered by Project Hayat Core v2.5<br/>
                Flash Image & Pro Logic
              </p>
            </div>
          </div>
        </aside>
      </main>

      {/* Footer Status Bar */}
      <footer className="h-8 border-t border-slate-800 bg-slate-900/90 flex items-center px-4 justify-between">
        <div className="flex items-center gap-6">
           <div className="flex items-center gap-2">
             <div className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
             <span className="text-[10px] text-slate-500 uppercase">Comm Link 1: Operational</span>
           </div>
           <div className="flex items-center gap-2">
             <div className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
             <span className="text-[10px] text-slate-500 uppercase">Comm Link 2: Operational</span>
           </div>
        </div>
        <div className="flex items-center gap-2 text-[10px] text-slate-600">
           <span className="uppercase tracking-widest italic font-bold">Humanity. Technology. Resilience.</span>
        </div>
      </footer>
    </div>
  );
};

export default App;
