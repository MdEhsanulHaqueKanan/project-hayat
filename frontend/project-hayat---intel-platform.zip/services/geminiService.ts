
import { GoogleGenAI, Type } from "@google/genai";
import { Detection, RescuePlan } from "../types";

export const generateRescuePlan = async (detections: Detection[]): Promise<RescuePlan> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  
  const prompt = `
    Analyze the following earthquake detection data and generate a strategic rescue plan for the UAV squad.
    Detections: ${JSON.stringify(detections)}
    
    Current focus: Antakya region, Turkey-Syria border.
    Provide a concise tactical summary, priority zones, a recommended safe path description, and any immediate hazards.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            summary: { type: Type.STRING },
            priorityZones: { 
              type: Type.ARRAY, 
              items: { type: Type.STRING } 
            },
            safePath: { type: Type.STRING },
            warnings: { 
              type: Type.ARRAY, 
              items: { type: Type.STRING } 
            },
          },
          required: ["summary", "priorityZones", "safePath", "warnings"]
        }
      }
    });

    const result = JSON.parse(response.text || "{}");
    return result as RescuePlan;
  } catch (error) {
    console.error("Gemini Error:", error);
    return {
      summary: "Error generating real-time intel. Relying on local pre-computed routing.",
      priorityZones: ["Sector A (Critical)", "Sector B (Audio Detection)"],
      safePath: "Northern arterial road remains clear of major debris.",
      warnings: ["Connectivity intermittent", "Secondary aftershocks likely"]
    };
  }
};
